<?php
    if(isset($_GET['ok'])){
      if($_GET['ok'] == true){
        echo "<div class='alert alert-success'>Vous avez postée votre sujet avec succès</div>";
      }
    }
  ?>
<html>
<head>
<title>Lecture d'un sujet</title>
<link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
</head>
<body>

<?php
if (isset($_GET['id'])) {
	echo 'Sujet non défini.';
}
else {
	
	$bdd= new PDO("mysql:host=127.0.0.1;dbname=TP3","root","");

	// on prépare notre requête
	$req = $bdd->query("SELECT auteur, message FROM sujets LIMIT 0,3");
		?>
	<div class="container spacer col-md-6 col-md-offset-3">
      	<div class="panel panel-primary">
      		<div class="panel-heading">Les Sujets Postes</div>
      		<div class="panel-body">
      			<table class="table table-bordered table-striped">
		<tr>
			<td>Auteur</td>
			<td>Messages</td>
			<td>Action</td>
		</tr>
		<?php while ($resultat = $req->fetch()) {?>
		<tr>
			<td><?php echo $resultat['auteur']?></td>
			<td>
				<div><?php echo substr(htmlentities($resultat['message']),0, 100);?></div>
				    	<div id="id"><?php echo substr(htmlentities($resultat['message']),100, 1000);?><a href="lire.php"> [Voir moins]</a></div>
			    </div>
			</td>
			<td><a href="reponse.php" class="btn btn-success">Répondre</a></td>
		</tr>
			<?php
				}
    		?>
    		<a href="lire3.php">[Afficher toutes les sujets]</a>
    	
   	</table>
   	</div>
   </div>
</div> 		
	<?php
}
?>
<br />
<br />

<a href="insert.php" class="btn btn-primary">Retour a la page insertion</a>

</body>
</html>


