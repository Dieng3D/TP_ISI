
<html>
<head>
<title>Insertion d'un nouveau sujet</title>
     <link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
</head>

<body>
	<font size="6" face="times new roman" color="white">Insertion d'un nouveau sujet</font></p>
     <div class="container spacer col-md-4 col-md-offset-4">
     	<div class="panel panel-primary">
     		<div class="panel-body">

						<form action="" method="POST">

	                        <div class="form-group">
    						  <label class="control-label">Auteur</label>
     						  <input type="text" name="auteur" maxlength="30" size="50" class="form-control" value="<?php if (isset($_POST['auteur'])) echo htmlentities(trim($_POST['auteur'])); ?>">
  						    </div>

         				    <div class="form-group">
            				   <label class="control-label">Titre</label>
                               <input type="text" name="titre" maxlength="50" size="50" class="form-control" value="<?php if (isset($_POST['titre'])) echo htmlentities(trim($_POST['titre'])); ?>">
    						</div>

                            <div class="form-group">
      							<label class="control-label">Message</label>
      							<textarea name="message" cols="50" class="form-control" rows="10"><?php if (isset($_POST['message'])) echo htmlentities(trim($_POST['message'])); ?>
      							</textarea>
  							</div>
        
                                <input type="submit" name="valider" value="AddPub" class="btn btn-primary">

                        </form>
            </div>
      </div>
  </div>                  

<?php
// on teste si le formulaire a été soumis
if (isset($_POST['valider'])) {
	// on teste la déclaration de nos variables
	if (!isset($_POST['auteur']) || !isset($_POST['titre']) || !isset($_POST['message'])) {
	$erreur = 'Les variables nécessaires au script ne sont pas définies.';
	}
	else {
	// on teste si les variables ne sont pas vides
	if (empty($_POST['auteur']) || empty($_POST['titre']) || empty($_POST['message'])) {
		$erreur = 'Au moins un des champs est vide.';
	}

	// si tout est bon, on peut commencer l'insertion dans la base
	else {
		// on se connecte à notre base
		$bdd= new PDO("mysql:host=127.0.0.1;dbname=TP3","root","");
		

		$req=$bdd->prepare("INSERT INTO sujets(auteur,titre,message) VALUES(?,?,?)");

		$req->execute(array($_POST['auteur'],$_POST['titre'],$_POST['message']));

		 header('location:lire.php?ok=true');

		?>
		<?php
		}}}
		?>
</body>
</html>