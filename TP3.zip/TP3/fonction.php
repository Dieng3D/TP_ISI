<?php

function substrws( $text, $len=180 )
 {
 
    if( (strlen($text) > $len) ) {
 
        $whitespaceposition = strpos($text," ",$len)-1;
 
        if( $whitespaceposition > 0 )
            $text = substr($text, 0, ($whitespaceposition+1));
 
        // close unclosed html tags
        if( preg_match_all("|<([a-zA-Z]+)>|",$text,$aBuffer) ) {
 
            if( !empty($aBuffer[1]) ) {
 
                preg_match_all("|</([a-zA-Z]+)>|",$text,$aBuffer2);
 
                if( count($aBuffer[1]) != count($aBuffer2[1]) ) {
 
                    foreach( $aBuffer[1] as $index => $tag ) {
 
                        if( empty($aBuffer2[1][$index]) || $aBuffer2[1][$index] != $tag)
                            $text .= '</'.$tag.'>';
                    }
                }
            }
        }
    }
 
    return $text;
}


function toggle_text(id) {
  var span = document.getElementById(id);
  if(span.style.display == "none") {
    span.style.display = "inline";
  } else {
    span.style.display = "none";
  }
}
?>