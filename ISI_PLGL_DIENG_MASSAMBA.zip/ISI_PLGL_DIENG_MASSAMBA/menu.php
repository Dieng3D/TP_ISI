<?php
   // session_start();
    if (isset($_POST['connect'])) {
      
      $login=htmlspecialchars(trim($_POST['login']));
      $mdp=htmlspecialchars(trim($_POST['mdp']));

      if (empty($login) or empty($mdp)) {
        echo "tu doit remplire tous les champs";
      }else
      if (isset($login) and !empty($login)) {
        if (isset($login) and !empty($login)) {
           if ($login=="mass" and $mdp=="passer" and $profile=="admin") {
             echo "vous etes administrateur";
             }else{
             echo "vous n'etes pas administrateur";
           }

        }
        
      }else{
        echo "verifier ton login";
      }
    }
?>
<?php
/*
      $db = mysqli_connect ("localhost", "root" , "");

if( isset($_POST['menu'])){
   session_start( );
 
  $login = mysql_real_escape_string( $_POST['login']);
  $mdp = mysql_real_escape_string( $_POST['mdp']);
  $profile = mysql_real_escape_string( $_POST['profile']);


if ($profile == "1" ){

  /* appel d'une connection avec la base de donnee
 $conn=mysql_connect("localhost","root","") or die(mysql_error());
    mysql_select_db("tp_php",$conn)or die(mysql_error());


$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$email=$_POST['email'];
$tel=$_POST['tel'];
$login=$_POST['login'];
$mdp=$_POST['mdp'];
    
    $req="insert into user(nom,prenom,email,tel,login,mdp) values ('$nom','$prenom','$email','$tel','$login','$mdp')";
   mysql_query($req)or(die(mysql_error()));

}
}
*/
?>




<!DOCTYPE html>
<html>
<head>
	<title>Connexion</title>
          <link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
          <link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
     <div class="row"> </div>
     <div class="col-md-4"> </div>
     <div class="col-md-4"> </div>

<p><font size="6" face="times new roman" color="white"><br>Bienvenu au MENU <br>ici seule les administrateurs peuvent se connecter si vous etez utilisateurs vous devez s'inscrire MERCI</font></p>
     <div class="container spacer col-md-3 col-md-offset-3">
     	<div class="panel panel-primary">
     		<div class="panel-body">
     			<form method="POST" action="formulaire.php">

                        <div class="form-group">
                           <label class="control-label">login</label>
                           <input type="text" name="login" class="form-control">
                       </div>
                        <div class="form-group">
                           <label class="control-label">mot de passe</label>
                           <input type="password" name="mdp" class="form-control">
                       </div>
                         <label>Profile</label>
                        <select name="profile">
                            <option value="">Faites votre choix</option>
                            <option value="1">user</option>
                            <option value="2">admin</option>
                        </select>    
                        <a href="traitement/listeadministrateur.php" class="btn btn-primary" name="connect">Connexion</a>
                        
                         <button name="valider" class="btn btn-success"><a href="formulaire.php"><font color="white">Inscription </font></a></button>
                        
     			      	  
                        
                         
     			</form>
     		</div>
     	</div>
     </div>
</body>
</html>
