<?php

   $bdd= new PDO('mysql:dbname=tp_php;host=localhost','root','');
?>