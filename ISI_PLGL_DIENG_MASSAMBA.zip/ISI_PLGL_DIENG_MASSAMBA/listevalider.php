<?php
  echo 'Bonjour '.$_POST['nom'].' '.$_POST['prenom'].' '.' votre inscription est validé';

?>