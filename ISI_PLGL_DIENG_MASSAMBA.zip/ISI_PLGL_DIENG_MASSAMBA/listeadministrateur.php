
<!DOCTYPE html>
<html>
<head>
	<title>Liste des utilisateurs</title>
	<link rel="stylesheet" type="text/css" href="bootstrap-cerulean.min.css">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
      <div class="container spacer col-md-6 col-md-offset-3">
      	<div class="panel panel-primary">
      		<div class="panel-heading">Liste des utilisateurs qui attend leurs validations</div>
      		<div class="panel-body">
      			<table class="table table-bordered table-striped">
      			    <tr>
      			    	<th>Nom</th>
      			    	<th>Prenom</th>
      			    	<th>Email</th>
                  <th>Telephone</th>
                  <th>login</th>
                  
                  <th>OPTION</th>
      			    </tr>
      			    <?php
   require_once("Acceuil.php");

   $req="select * from user";
   $rs=mysql_query($req) or die(mysql_error());

?>

<html>
  
   <body>
 <table>
  <tr>
 <th>
     <table border="5" width="100%">
      <tr bgcolor="blue">
         <th><font size="2" face="algerian" color="white">NOM</font></th>
         <th><font size="2" face="algerian" color="white">PRENOM</font></th> 
         <th><font size="2" face="algerian" color="white">EMAIL</font></th>
         <th><font size="2" face="algerian" color="white">TELEPHONE</font></th>
         <th><font size="2" face="algerian" color="white">LOGIN</font></th>

      </tr>

      <?php while($ET=mysql_fetch_assoc($rs))  //cette fonction permet de recuperer une ligne et d'aller directement a la ligne
      {?> 
        <tr>
          <td><font color="white"><?php echo ($ET['nom'])?></font></td>
          <td><font color="white"><?php echo ($ET['prenom'])?></font></td>
          <td><font color="white"><?php echo ($ET['email'])?></font></td>
          <td><font color="white"><?php echo ($ET['tel'])?></font></td>
          <td><font color="white"><?php echo ($ET['login'])?></font></td>
          
          <td type="submit" class="btn btn-success" width="100%"><a href="listevalider.php?email=<?php echo ($ET['email'])?>">valider</a></td>

        </tr>
        <?php } ?>  
     </table>
 
 </th>
      		    </table>
      		</div>
      	</div>
      
      </div>
</body>
</html>