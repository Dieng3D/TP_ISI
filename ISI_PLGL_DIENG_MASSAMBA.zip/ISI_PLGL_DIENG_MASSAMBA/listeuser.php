
<!DOCTYPE html>
<html>
<head>
	<title>Liste des utilisateurs</title>
	<link rel="stylesheet" type="text/css" href="bootstrap-cerulean.min.css">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
      <div class="container spacer col-md-6 col-md-offset-3">
      	<div class="panel panel-primary">
      		<div class="panel-heading">Liste des utilisateurs</div>
      		<div class="panel-body">
      			<table class="table table-bordered table-striped">
      			    <tr>
      			    	<th>Nom</th>
      			    	<th>Prenom</th>
      			    	<th>Email</th>
                  <th>Telephone</th>
                  <th>login</th>
                  
      			    </tr>
      			    	<?php
                   
                    require_once 'Acceuil.php';
                    $result = listeuser();
                    while ($tab = mysqli_fetch_assoc($result)) 
                    {
                      echo "<tr>";
                      echo "<td>$tab[nom]</td>";
                      echo "<td>$tab[prenom]</td>";
                      echo "<td>$tab[email]</td>";
                      echo "<td>$tab[tel]</td>";
                      echo "<td>$tab[login]</td>";
                      
                      echo "</tr>";
                    }
                  ?>
      		    </table>
      		</div>
      	</div>
      
      </div>
</body>
</html>