

<!DOCTYPE html>
<html>
<head>
	<title>Connexion</title>
          <link rel="stylesheet" type="text/css" href="bootstrap-cerulean.min.css">
           <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
     <div class="row"> </div>
     <div class="col-md-4"> </div>
     <div class="col-md-4"> </div>

<p><font size="5" face="times new roman" color="white">Veuillez remplire les champs suivants</font></p>
     <div class="container spacer col-md-3 col-md-offset-3">
     	<div class="panel panel-primary">
     		<div class="panel-body">
     			<form method="POST" action="listeuser.php">
     			   <div class="form-group">
     			   	  <label class="control-label">nom</label>
     			   	  <input type="text" name="nom" class="form-control">
     			   </div>
				   <div class="form-group">
     			   	  <label class="control-label">Prenom</label>
     			   	  <input type="text" name="prenom" class="form-control">
     			   </div>
     			    <div class="form-group">
     			   	  <label class="control-label">Email</label>
     			   	  <input type="text" name="email" class="form-control">
     			   </div>
				   <div class="form-group">
     			   	  <label class="control-label">Telephone</label>
     			   	  <input type="number" name="tel" class="form-control">
     			   </div>
     			    <div class="form-group">
     			   	  <label class="control-label">login</label>
     			   	  <input type="text" name="login" class="form-control">
     			   </div>
     			    <div class="form-group">
     			   	  <label class="control-label">MDP</label>
     			   	  <input type="password" name="mdp" class="form-control">
     			   </div>
				  <button name="valider" class="btn btn-primary">Inscription</button>
                        
     		</div>
     	</div>
     </div>
</body>
</html>

