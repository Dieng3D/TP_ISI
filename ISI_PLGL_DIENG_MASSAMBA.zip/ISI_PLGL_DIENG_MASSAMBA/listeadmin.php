<?php 
  require_once 'connexion.php';  /* appel d'une connection avec la base de donnee*/
    $nom=$_POST['nom'];
    $prenom=$_POST['prenom'];
     $email=$_POST['email'];
    $tel=$_POST['tel'];
     $login=$_POST['login'];
    $mdp=$_POST['mdp'];
   
   

    $req="insert into user(nom,prenom,email,tel,login,mdp) values ('$nom','$prenom','$email','$tel','$login','$mdp')";
    mysql_query($req)or(die(mysql_error()));
?>
