<?php

  function debug($var){
  	echo '<pre>'.print_r($var,true).'<pre>';
  }