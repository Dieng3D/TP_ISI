<?php
    require_once 'connexion.php';
    function formulaire($nom,$prenom,$email,$tel,$login,$mdp)
    {
      $sql="INSERT INTO user VALUES ('$nom','$prenom','$email','$tel','$login','$mdp')";
      return executeSQL($sql);
    }

    function listeuser()
    {
      $sql= "SELECT * FROM user";
      $rs=mysql_query($sql) or die(mysql_error());
      return executeSQL($rs);
    }
?>