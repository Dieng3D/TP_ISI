
<div class="row">
<?php
foreach ( $inst->traitement("Select * from posts") as $key => $value){?>
        <div class="row">
            <h3> <?= $value->titre;?></h3>
            <p>
                <?= $value->contenu; ?>
            </p>
        </div>

<?php } ?>

</div>


                     <form action="posts.php" method="POST">
         				    <div class="form-group">
            				   <label class="control-label">Titre</label>
                               <input type="text" name="titre" maxlength="50" size="50" class="form-control" value="<?php if (isset($_POST['titre'])) echo htmlentities(trim($_POST['titre'])); ?>">
    						</div>

                            <div class="form-group">
      							<label class="control-label">Contenu</label>
      							<textarea name="contenu" cols="50" class="form-control" rows="10"><?php if (isset($_POST['contenu'])) echo htmlentities(trim($_POST['contenu'])); ?>
      							</textarea>
  							</div>
        
                                <input type="submit" name="valider" value="AddPub" class="btn btn-primary">

                        </form>