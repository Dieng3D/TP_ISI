
 <h1>Post </h1>
<div class="row">
<?php
$idP = $_GET["idP"];
$sql = "Select * from posts where idP=?";
foreach ( $inst->traitement($sql) as $key => $value){?>
    <div class="row">
        <h1> <?= $value->titre; ?></h1>
        <p>
            <?= $value->contenu;?>
        </p>
    </div>

<?php } ?>

</div>