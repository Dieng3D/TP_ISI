<?php

namespace  Application\DataBase\Table;
class Commentaire
{

    public function getUrl(){
       return  "index.php?page=posts&id=$this->idC";
    }
}