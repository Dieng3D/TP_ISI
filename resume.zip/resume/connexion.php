<?php session_start();
include 'fonction/fonction.php';
include 'fonction/connexion.class.php';
$bd=bdd();
 if (isset($_POST['pseudo']) AND isset($_POST['mdp'])) {
      $connexion = new connexion($_POST['pseudo'],$_POST['mdp']);
       $verification = $connexion->verification();
      if ($verification=='ok') {
        if ($connexion->session()) {
          header('Location: index.php');
        }

      }
      else{
        $erreur = $verification;
      }

    }

	?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Mon super site</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet">
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/resume.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
    <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-block d-lg-none">FORUM DE DISCUSSION</span>
      <span class="d-none d-lg-block">
      <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="img/status.jpg" alt="">
      </span>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <form align="right"><a href="inscription.php" class="btn btn-primary">S'inscrire</a></form>
                
</nav>
  <div class="container-fluid p-0">

    <section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="about">
      <div class="w-100">

   
    
     			<form method="POST" action="connexion.php">
     			   <div class="form-group">
     			   	  <label class="control-label">Pseudo</label>
     			   	  <input type="text" name="pseudo" class="form-control" placeholder="Pseudo..." required />
     			   </div>
				  
				   <div class="form-group">
     			   	  <label class="control-label">Mot de passe</label>
     			   	  <input type="password" name="mdp" class="form-control" placeholder="Mot de passe..." required />
     			   </div>
     			   	   <input type="submit" class="btn btn-primary" value="Connecter">  

     			   	   <?php
                     if (isset($erreur)) {
                            echo $erreur;
                           }
                 ?>
     		 </form>
        </div>
      </section>
    </div>

        
      

 <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/resume.min.js"></script>

</body>

</html>

