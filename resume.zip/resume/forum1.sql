-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  Dim 18 août 2019 à 02:36
-- Version du serveur :  10.1.38-MariaDB
-- Version de PHP :  5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `forum1`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id`, `name`) VALUES
(1, 'lire les sujets postes'),
(2, 'je veux poster un sujet');

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

CREATE TABLE `commentaire` (
  `idc` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commentaire`
--

INSERT INTO `commentaire` (`idc`, `nom`, `comment`, `id`) VALUES
(1, 'dieng3D', 'je suis fatigue des insertions', 3);

-- --------------------------------------------------------

--
-- Structure de la table `inscription`
--

CREATE TABLE `inscription` (
  `idI` int(11) NOT NULL,
  `pseudo` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mdp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `inscription`
--

INSERT INTO `inscription` (`idI`, `pseudo`, `email`, `mdp`) VALUES
(1, 'mass3D', 'diengmassamba5@gmail.com', 'passer@1'),
(2, 'mass3D', 'diengmassamba5@gmail.com', 'passer@1'),
(3, 'abdoulaye', 'abdoulayefatoubarryba@gmail.com', '30103010'),
(4, 'BAYEee', 'djily@ieng', 'passer'),
(5, 'serigne', 'serigne@gmail.com', 'diallo'),
(6, 'elimane', 'cisse@gmail.com', 'passer');

-- --------------------------------------------------------

--
-- Structure de la table `sujet`
--

CREATE TABLE `sujet` (
  `id` int(11) NOT NULL,
  `auteur` varchar(255) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `contenu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sujet`
--

INSERT INTO `sujet` (`id`, `auteur`, `titre`, `contenu`) VALUES
(3, 'Demba Dieng', 'pharmacie', '               Quels sont les documents Ã  fournir ?\r\n\r\nUne demande manuscrite adressÃ©e au ministre chargÃ© de la SantÃ© signÃ©e par le pharmacien responsable de l\'entreprise\r\nUne copie lÃ©galisÃ©e du diplÃ´me du pharmacien responsable\r\nUne attestation d\'expÃ©rience du pharmacien responsable (curriculum vitae) Joindre les piÃ¨ces justificatives d\'une expÃ©rience acquise dans le domaine de la distribution\r\nUne demande d\'inscription, Ã  la section B de l\'Ordre des Pharmaciens\r\nUn extrait de casier judiciaire datant de moins de 3 mois\r\nUn extrait de naissance datant de moins de 3 mois\r\nUn certificat de nationalitÃ© sÃ©nÃ©galaise\r\nLe procÃ¨s verbal du conseil d\'administration de la sociÃ©tÃ© dÃ©signant\r\nnominativement  le pharmacien responsable s\'il y a lieu\r\nLe procÃ¨s verbal de l\'assemblÃ©e gÃ©nÃ©rale consÃ©cutive ou statuts de la sociÃ©tÃ©, s\'il y a lieu\r\nLa liste des actionnaires (et leur qualitÃ©) faisant Ã©tat de la rÃ©partition du capital social de la sociÃ©tÃ© entre actionnaire (les pharmaciens doivent dÃ©tenir au moins 51% du capital â€¦.), s\'il y a lieu\r\nLa dÃ©claration aux fins d\'immatriculation au registre de commerce\r\nLe contrat de bail ou d\'achat des locaux ou le compromis d\'achat du terrain ou le titre de propriÃ©tÃ© du terrain ou des locaux\r\nLa liste du matÃ©riel prÃ©vu pour la mise en marche de la sociÃ©tÃ© (moyens de transport et moyens de gestion)      \r\nLe dossier joint Ã  la demande d\'autorisation d\'ouverture doit Ãªtre Ã©tabli et transmis en 3 exemplaires.\r\n\r\nNB. : En cas de modification envisagÃ©e, la demande de modification doit Ãªtre adressÃ©e au ministre chargÃ© de la SantÃ© par le pharmacien responsable. La nature de la modification doit Ãªtre prÃ©cise et toutes les piÃ¨ces justificatives doivent Ãªtre jointes Ã  la demande.\r\n\r\nLe pharmacien responsable de l\'Ã©tablissement doit faire connaÃ®tre au ministre de la SantÃ© :\r\n\r\nLa date effective de l\'ouverture de l\'Ã©tablissement\r\nLa date Ã  la quelle a Ã©tÃ© rÃ©alisÃ© la modification\r\nLa date de fermeture temporaire ou dÃ©finitive de l\'Ã©tablissement     '),
(4, 'Dieng3D', 'Informatique', '              L\'ordinateur offre de nouvelles possibilitÃ©s de recherches aux chercheurs en sciences humaines. Les instruments de travail\r\nconstituÃ©s grÃ¢ce au traitement automatique des textes leur permettent d\'aborder les Å“uvres d\'une autre maniÃ¨re en leur livrant\r\ndes relevÃ©s exhaustifs concernant les caractÃ¨res linguistiques de ces Å“uvres. L\'informatique constitue une science auxiliaire\r\ntrÃ¨s prÃ©cieuse pour le chercheur, une aide indispensable pour l\'analyse d\'un texte sous ses diffÃ©rents aspects, mais l\'ordinateur\r\nne remplacera jamais l\'homme dans sa quÃªte du sens des Å“uvres qu\'il Ã©tudie.\r\nAbstract\r\nThe computer offers new possibilities to those carrying out research in the humane sciences. The work-tools cons tituted by\r\nmeans of automatic treatment of the textes allow of a fresh approach to the works by supplying exhaustive surveys of the\r\nlinguistic caracteristics of these works. Informatics constitutes a highly valuable auxiliary science for those involved in research,\r\nan indispensable aid for the analysis of a text from its different p      '),
(5, 'abdoulaye', 'tester', '                    L\'activitÃ© de cet emploi/mÃ©tier s\'exerce au sein de services de maintenance d\'entreprises industrielles, de transport, de sociÃ©tÃ©s de services, du service aprÃ¨s-vente d\'un constructeur ou distributeur d\'Ã©quipements, en relation avec diffÃ©rents services (production, mÃ©thodes, sÃ©curitÃ©, ...). Elle peut impliquer des dÃ©placements.\r\nElle varie selon le secteur d\'activitÃ© (mÃ©tallurgie, sidÃ©rurgie, ferroviaire, ...), le mode d\'organisation (topomaintenance, ...), le degrÃ© d\'automatisation et le type d\'Ã©quipement.\r\nElle peut s\'exercer les fins de semaine, jours fÃ©riÃ©s, de nuit et Ãªtre soumise Ã  des astreintes.\r\nLe port d\'Ã©quipements de protection (chaussures de sÃ©curitÃ©, gants, ...) est requis.'),
(6, 'Diaz', 'titre du texte', '                   Envisager de rendre compte de lâ€™ensemble des rÃ©alitÃ©s de la construction mÃ©canique du xxie siÃ¨cle, câ€™est considÃ©rer dâ€™emblÃ©e le caractÃ¨re industriel dâ€™une activitÃ© incluant les technologies les plus diverses, de l\'Ã©lectricitÃ© Ã  l\'informatique, et recouvrant les besoins de la construction de vÃ©hicules terrestres, aÃ©riens, spatiaux, ainsi que les machines permettant de construire ces machines. Cependant, la construction mÃ©canique reste au cÅ“ur de lâ€™industrie, tant dâ€™un point de vue historique (jusquâ€™aux annÃ©es 1950, la conception de produits industriels est essentiellement perÃ§ue au travers de la Â« mÃ©canique Â») que dâ€™un point de vue structurel (si diverses soient les technologies, la conception dâ€™un produit industriel restera toujours tributaire de considÃ©rations liÃ©es Ã  la rÃ©sistance mÃ©canique). '),
(7, 'djily', 'test2', '          EX: trier par ordre croissant suivant la taill et par ordre decroissant suivant le premier element de chaine\r\nvar tri= from p in opersonnes\r\norderby p.length,p[0] descending\r\nselect p\r\n//afficher les notes des etudiants a examen\r\n//var req=etudiants.where(e=>e.id == 5).Join(note,e=>e.id,n=> n.idEtudiant,(e,n)=>$\"{n.valeur}\")\r\n.Tolist(0.foreach(consol.readline);          ');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `commentaire`
--
ALTER TABLE `commentaire`
  ADD PRIMARY KEY (`idc`),
  ADD KEY `ids` (`id`);

--
-- Index pour la table `inscription`
--
ALTER TABLE `inscription`
  ADD PRIMARY KEY (`idI`);

--
-- Index pour la table `sujet`
--
ALTER TABLE `sujet`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `commentaire`
--
ALTER TABLE `commentaire`
  MODIFY `idc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `inscription`
--
ALTER TABLE `inscription`
  MODIFY `idI` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `sujet`
--
ALTER TABLE `sujet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commentaire`
--
ALTER TABLE `commentaire`
  ADD CONSTRAINT `commentaire_ibfk_1` FOREIGN KEY (`id`) REFERENCES `sujet` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
