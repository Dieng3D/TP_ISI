<?php session_start();
include 'fonction/fonction.php';
include 'fonction/commentaire.class.php';
$bd=bdd();

  



// on teste si le formulaire a été soumis
if (isset($_POST['okk'])) {
  // on teste la déclaration de nos variables
  if (!isset($_POST['nom']) || !isset($_POST['comment'])) {
  $erreur = 'Le variable nécessaire au script n est pas définies.';
  }
  else {
  // on teste si les variables ne sont pas vides
  if (empty($_POST['nom']) || empty($_POST['comment'])) {
    $erreur = 'Au moins un des champs est vide.';
  }

  // si tout est bon, on peut commencer l'insertion dans la base
  else {
    // on se connecte à notre base
    $bdd= new PDO("mysql:host=127.0.0.1;dbname=forum1","root","");
    

    $req=$bdd->prepare("INSERT INTO commentaire(nom,comment) VALUES(?,?)");

    $req->execute(array($_POST['nom'],$_POST['comment']));

     header('location:index.php?ok=true');

   
  
    }
  }
}
   

	?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Mon super forum</title>
	<link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
    <link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<p><font size="6" face="times new roman" color="white">BIENVENU DANS LA PAGE COMMENTAIRE</font></p>
     <div class="container spacer col-md-3 col-md-offset-3">
     	<div class="panel panel-primary">
     		<div class="panel-body">
     			  
     		</div>
     	</div>
     </div>


</body>
</html>

