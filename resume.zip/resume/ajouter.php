<?php session_start();
include 'fonction/fonction.php';
include 'fonction/ajouter.class.php';
$bd=bdd();



// on teste si le formulaire a été soumis
if (isset($_POST['valider'])) {
  // on teste la déclaration de nos variables
  if (!isset($_POST['auteur']) || !isset($_POST['titre']) || !isset($_POST['contenu'])) {
  $erreur = 'Les variables nécessaires au script ne sont pas définies.';
  }
  else {
  // on teste si les variables ne sont pas vides
  if (empty($_POST['auteur']) || empty($_POST['titre']) || empty($_POST['contenu'])) {
    $erreur = 'Au moins un des champs est vide.';
  }

  // si tout est bon, on peut commencer l'insertion dans la base
  else {
    // on se connecte à notre base
    $bdd= new PDO("mysql:host=127.0.0.1;dbname=forum1","root","");
    

    $req=$bdd->prepare("INSERT INTO sujet(auteur,titre,contenu) VALUES(?,?,?)");

    $req->execute(array($_POST['auteur'],$_POST['titre'],$_POST['contenu']));

     header('location:index.php?ok=true');

   
  
    }
  }
}
   

	?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Mon super site</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet">
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/resume.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
    <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-block d-lg-none">FORUM DE DISCUSSION</span>
      <span class="d-none d-lg-block">
      <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="img/status.jpg" alt="">
      </span>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
                
</nav>
  <div class="container-fluid p-0">

    <section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="about">
      <div class="w-100">

     			  <form method="POST" action="ajouter.php">
                 <div class="form-group">
                  <label class="control-label">Auteur</label>
                  <input type="text" name="auteur" maxlength="30" size="50" class="form-control" value="<?php if (isset($_POST['auteur'])) echo htmlentities(trim($_POST['auteur'])); ?>">
                  </div>

                    <div class="form-group">
                       <label class="control-label">Titre</label>
                               <input type="text" name="titre" maxlength="50" size="50" class="form-control" value="<?php if (isset($_POST['titre'])) echo htmlentities(trim($_POST['titre'])); ?>">
                     </div>

                     <div class="form-group">
                        <label class="control-label">Contenu</label>
                        <textarea name="contenu" cols="50" class="form-control" rows="10"><?php if (isset($_POST['contenu'])) echo htmlentities(trim($_POST['contenu'])); ?>
                    </textarea>
                </div>
        
                                <input type="submit" name="valider" value="Ajouter" class="btn btn-primary">
                                 <form align="right"><a href="index.php" class="btn btn-danger">Retour</a></form>

                       
                  <?php 
                  if (isset($erreur)) {
                    return $erreur;
                  }
                  ?>
     		       
          </form>
        </div>
      </section>
    </div>

        
      

 <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/resume.min.js"></script>

</body>

</html>

