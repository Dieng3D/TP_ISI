<?php session_start();
include 'fonction/fonction.php';
$bd=bdd();

if (!isset($_SESSION['idI'])) {
	
	header('Location: index.html');
}
else
{
	?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>FORUM DE DISCUSSION</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet">
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/resume.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
    <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-block d-lg-none">FORUM DE DISCUSSION</span>
      <span class="d-none d-lg-block">
        <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="img/status.jpg" alt="">
      </span>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav">
         <?php
  if (isset($_GET['categorie'])) {
  //si on est dans une categorie
    $_GET['categorie'] =htmlspecialchars($_GET['categorie']);
    ?>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="lire/lire.php"><font color="black">**</font>lire les sujets poster</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="ajouter.php"><font color="black">**</font>Ajouter un sujet</a>
        </li>
         <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="deconnexion.php"><font color="black">**</font>DECONNECTER</a>
        </li>
      </ul>
    </div>
  </nav>

  <div class="container-fluid p-0">

<section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="about">
      <div class="w-100">
        <h1 class="mb-0">FORUM DE
          <span class="text-primary">DISCUSSION</span>
        </h1>
        
        <p class="lead mb-5">Veuillez choisir votre option dans le menu vertical qui est a gauche</p>
       
        </div>
    </section>


  </div>

 
    
     <?php
      }else{
    echo '<h3><font size="4" face="time new roman" color="white">Bienvenu <font color="black">'.$_SESSION['pseudo'].'</font> vous avez connecté avec succée <a
    href="deconnexion.php"></font></h3>';
    $requete = $bd->query('SELECT * FROM categorie');
    while($reponse = $requete->fetch()){
  ?>
          </font>
        </li>
      </ul>
  </nav>
           
      <div class="form-group">
        
        <form class="btn btn-info"><font size="4" face="time new roman" color="white"><a href="index.php?categorie=<?php echo $reponse['name']; ?>"><i><font size="4" face="time new roman" color="white"><?php echo $reponse['name']; ?></font></i></a></form>
        
      </div>
      <?php
     }
    }}
     ?>

   


  </div>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/resume.min.js"></script>

</body>

</html>
