<?php
  require_once 'fonction.php';

 
  class ajouter
  {
  	private $auteur;
  	private $titre;
  	private $contenu;
  	private $bd;
  	
  	public function __construct($auteur,$titre,$contenu)
  	{
  		$this->auteur = htmlspecialchars($auteur);
  		$this->titre = htmlspecialchars($titre);
  		$this->contenu = htmlspecialchars($contenu);
  		$this->bd = bdd();
  	}
     

       /*public function getDB(){
             
        $this->db_name = 'TP44';
        $this->db_pass = '';
        $this->db_user = 'root';
        $dbh = new PDO('mysql:host=localhost;db_name='.$this->db_name,$this->db_pass,$this->db_user);
    }*/

       public function traitement($sql){
        $el = $this->bdd()->query($sql);
        $all = $el->fetchAll(\PDO::FETCH_OBJ);
        return  $all;
    }

    }

?>