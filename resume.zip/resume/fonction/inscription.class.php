<?php
//session_start();
require_once 'fonction.php';   

class inscription
{
	private $pseudo;
	private $email;
	private $mdp;
	private $mdp2;
	private $bd;

	public function __construct($pseudo,$email,$mdp,$mdp2)
	{
		$pseudo=htmlspecialchars($pseudo);
		$email=htmlspecialchars($email);

		$this->pseudo=$pseudo;
		$this->email=$email;
		$this->mdp=$mdp;
		$this->mdp2=$mdp2;
		$this->bd=bdd();
	}
   
	public function verification()
	{
		if (strlen($this->pseudo)>5 AND strlen($this->pseudo)<20) {
			
				if (strlen($this->mdp)>5 AND strlen($this->mdp)<20) {
						if ($this->mdp=$this->mdp2) {
							return 'oki';
						}
						else
						{
							$erreur = 'les deux mot de passe doivent etre identiques';
			                return $erreur;
						}
				}else{
					$erreur = 'le mot de passe doit comporter entre 5 et 20 caractere';
			        return $erreur;
				}
		}
		else
		{
			$erreur = 'Pseudo doit comporter entre 5 et 20 caractere';
			return $erreur;
		}
	}


  public function enregistrement(){
  	 $requete = $this->bd->prepare('INSERT INTO inscription(pseudo,email,mdp) VALUES(:pseudo,:email,:mdp)');
  	 $requete->execute(array('pseudo'=>$this->pseudo,'email'=>$this->email,'mdp'=>$this->mdp));

  	 return 1;
  }

  
  public function session(){

  	$requete=$this->bd->prepare('SELECT idI FROM inscription WHERE pseudo = :pseudo');
  	 $requete->execute(array('pseudo'=>$this->pseudo));
  	 $requete=$requete->fetch();
  	 $_SESSION['idI']=$requete['idI'];
  	  $_SESSION['pseudo']=$this->pseudo;


  	 	return 1;
  }
  


}