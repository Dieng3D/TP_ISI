<?php 

function bdd()
{
	try {
		$bd =  new PDO("mysql:dbname=forum1;host=127.0.0.1", "root", "");
	} catch (Exception $e) {
		echo $e;
	}
	return $bd;
}

?>