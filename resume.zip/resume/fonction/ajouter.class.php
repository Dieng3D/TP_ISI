<?php
  require_once 'fonction.php';

 
  class ajouter
  {
  	private $auteur;
  	private $titre;
  	private $contenu;
  	private $bd;
  	
  	public function __construct($auteur,$titre,$contenu)
  	{
  		$this->titre = htmlspecialchars($titre);
  		$this->titre = htmlspecialchars($titre);
  		$this->contenu = htmlspecialchars($contenu);
  		$this->bd = bdd();
  	}

  	/*public function verification(){
  		if (strlen($this->titre)>5 AND strlen($this->titre)<60) {
  			if (strlen($this->contenu)>0) {
  				return 'ok';
  			}
  			else{
  				$erreur='Veuillez entrer le contenu du sujet';
  			    return $erreur;
  			}

  		}
  		else{
  			$erreur='le titre du sujet doit compris en 5 et 20 caracteres';
  			return $erreur;
  		}
  			}

  			public function insert(){
  				$requete = $this->bd->prepare('INSERT INTO sujet(auteur,titre,contenu) VALUES(:auteur,:titre,:contenu');
  				$requete->execute(array('auteur'=>$this->auteur,'titre'=>$this->titre,'contenu'=>$this->contenu));
  				
  				return 1;
  			}*/

  	}

?>