<?php
  require_once 'fonction.php';

 
  class commentaire
  {
  	private $nom;
  	private $comment;
  	private $bd;
  	
  	public function __construct($nom,$comment)
  	{
  		$this->nom = htmlspecialchars($nom);
  		$this->comment = htmlspecialchars($comment);
  		$this->bd = bdd();
  	}

  	/*public function verification(){
  		if (strlen($this->titre)>5 AND strlen($this->titre)<60) {
  			if (strlen($this->comment)>0) {
  				return 'ok';
  			}
  			else{
  				$erreur='Veuillez entrer le comment du sujet';
  			    return $erreur;
  			}

  		}
  		else{
  			$erreur='le titre du sujet doit compris en 5 et 20 caracteres';
  			return $erreur;
  		}
  			}

  			public function insert(){
  				$requete = $this->bd->prepare('INSERT INTO sujet(nom,titre,comment) VALUES(:nom,:titre,:comment');
  				$requete->execute(array('nom'=>$this->nom,'titre'=>$this->titre,'comment'=>$this->comment));
  				
  				return 1;
  			}*/

  	}

?>