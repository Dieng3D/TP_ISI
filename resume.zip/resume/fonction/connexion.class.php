<?php

	include_once 'fonction.php';
	class connexion
	{
		private $pseudo;
	    private $mdp;
	    private $bd;

		public function __construct($pseudo,$mdp)
		{
			$this->pseudo=$pseudo;
		    $this->mdp=$mdp;
			$this->bd=bdd();
		}

		public function verification(){
		$requete = $this->bd->prepare('SELECT * FROM inscription WHERE pseudo = :pseudo');
		 $requete->execute(array('pseudo'=>$this->pseudo));
  	     $reponse=$requete->fetch();
  	     if ($reponse) {
  	     	if ($this->mdp==$reponse['mdp']) {
  	     		return 'ok';
  	     	}
  	     	else{
  	     		$erreur='le mot de passe est incorrect';
  	     	    return $erreur;
  	     	}
  	     }
  	     else{
  	     	$erreur='le pseudo est inexistant';
  	     	return $erreur;
  	     }

		}

		public function session(){

  	     $requete=$this->bd->prepare('SELECT idI FROM inscription WHERE pseudo = :pseudo');
  	     $requete->execute(array('pseudo'=>$this->pseudo));
  	     $requete=$requete->fetch();
  	     $_SESSION['idI']=$requete['idI'];
  	     $_SESSION['pseudo']=$this->pseudo;


  	 	return 1;
  }
  
	}
?>